app.directive('homeOptions',function(){
    return{
        restrict:'E',
        scope:{},
        templateUrl:'javascripts/directives/homeOptions.html'
    };
});