app.controller('myCtrl', function($scope) {
	
	$scope.drills = [
		{
			name:"Ball work",
			desc:"This drill will focus on a players ball work and aim to develop it within a structured and encouraging environment",
			link:"#!ballWork"
		}, 
		{
			name:"Handling",
			desc:"When playing hurling it is important that th player knows how to handle the hurl and ball",
			link:"#!handling"
		}, 
		{	
			name:"Stamina",
			desc:"fitness is an important part of the game so we need to build stamina for a player",
			link:"stamina"
		}
	]
	
	
});